<?php

return [
    'name' => 'TemplateSettings'
];
