<?php

return [
    'name' => 'HimalayaSms'
];
