<?php

return [
    'name' => 'MenuManage'
];
