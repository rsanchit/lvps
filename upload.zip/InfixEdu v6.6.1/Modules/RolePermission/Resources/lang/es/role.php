<?php
return [
    "add_role" => "Añadir rol",

    "edit_role" => "Editar rol",

    "update_role" => "Rol de actualización",

    "delete_role" => "Suprimir rol",

    "student_permission" => "Permiso de estudiante",

    "parents_permission" => "Permiso padre",

    "student_password" => "Contraseña del estudiante",

    "parents_password" => "Contraseña padre",

    "update_password" => "Actualizar contraseña",

    "Role" => "Función",

    "role_permission" => "Permiso de rol",

    "assign_permission" => "Asignar permiso",

    "role" => "Función",

    "role_&_permission" => "Permiso de rol",

    "login_permission" => "Permiso de acceso",

    "role_list" => "Lista de roles",

];