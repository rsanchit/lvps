<?php 
return [
    'role'=>'Role',
    'role_&_permission'=>'Role & Permission',
    'role_permission'=>'Role Permission',
    'role_list'=>'Role List',
    'add_role'=>'Add Role',
    'edit_role'=>'Edit Role',
    'update_role'=>'Update Role',
    'delete_role'=>'Delete Role',
    'assign_permission'=>'Assign Permission',
    'login_permission'=>'Login Permission',
    'student_permission'=>'Student Permission',
    'parents_permission'=>'Parent Permission',
    'student_password'=>'Student Password',
    'parents_password'=>'Parent Password',
    'update_password'=>'Update Password',
];