<?php
return [
    "add_role" => "Ajouter un rôle",

    "edit_role" => "Editer le rôle",

    "update_role" => "Mettre à jour rôle",

    "delete_role" => "Supprimer un rôle",

    "student_permission" => "Autorisation d'étudiant",

    "parents_permission" => "Droit parent",

    "student_password" => "Mot de passe étudiant",

    "parents_password" => "Mot de passe parent",

    "update_password" => "Mettre à jour le",

    "Role" => "Rôle",

    "role_permission" => "Droit de rôle",

    "assign_permission" => "Affecter une autorisation",

    "role" => "Rôle",

    "role_&_permission" => "Droit de rôle",

    "login_permission" => "Droit de connexion",

    "role_list" => "Liste des rôles",

];