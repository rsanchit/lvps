<?php
return [
    "bulkprint" => "Impresión a granel",

    "fees_bulk_print" => "Impresión a granel",

    "invoice_settings" => "Valores de factura",

    "invoice_prefix_format_standard_three_character" => "Prefijo de factura (formato estándar de tres caracteres)",

    "is_showing_signature" => "Está mostrando la firma",

    "copy_for" => "Copiar para",

    "invoice_no" => "Factura no",

    "generate" => "Generar",

    "showing_page" => "Mostrar página",

    "Generate" => "Generar",

    "Prefix" => "Prefijo",

    "grid_gap" => "Intervalo de cuadrícula",

    "select_certificate" => "Seleccionar certificado",

    "student_certificate" => "Certificado de estudiante",

    "generate_id_card" => "Generar tarjeta de ID",

    "bulk_print" => "Impresión a granel",

    "bulk" => "Graneles",

    "per" => "Por",

    "part" => "Parte",

    "is_showing" => "Está Mostrando",

    "format_standard_three_character" => "Carácter estándar de formato 3",

    "prefix" => "Prefijo",

    "fees_invoice_settings" => "Valores de factura de tarifas",

    "fees_invoice_bulk_print" => "Impresión masiva de facturas de tarifas",

    "payroll_bulk_print" => "Impresión a granel de nómina",

    "staff_id_card" => "Tarjeta de identificación del personal",

];