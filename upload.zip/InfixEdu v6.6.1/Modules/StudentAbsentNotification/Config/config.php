<?php

return [
    'name' => 'StudentAbsentNotification'
];
