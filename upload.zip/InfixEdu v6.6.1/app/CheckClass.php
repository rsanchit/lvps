<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckClass extends Model
{
    protected $table = 'sm_classes_new';

}
